﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginV2
{
    class User
    {
        private string userName, passWord, userID;

        public User() { }

        public User(string un, string pass, string usid)
        {
            UserName = un;
            PassWord = pass;
            UserID = usid;
        }

        public string UserName { get => userName; set => userName = value; }
        public string PassWord { get => passWord; set => passWord = value; }
        public string UserID { get => userID; set => userID = value; }
    }
}
