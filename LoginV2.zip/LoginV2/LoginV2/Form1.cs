﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginV2
{
    public partial class Form1 : Form
    {
        DataLayer dataHandler = new DataLayer();
        User currentUser = new User("", "", "-1");
        bool loginMatch = false;
        bool loggingIn = false;
        int userID = -1;
        DataForm adminForm = new DataForm();
        DataForm userForm = new DataForm();
        bool addingNew = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string welcomeMessage = "Welcome! In this program you can view created characters for Dungeons and Dragons." +
                " In addition you may also create your own account and characters.";

            MessageBox.Show(welcomeMessage);
        }

        private void BtnLogIn_Click(object sender, EventArgs e)
        {
            if (tbUsername.Text != "")
            {
                currentUser.UserName = tbUsername.Text;
                currentUser.PassWord = tbPassword.Text;
                loggingIn = true;
            }
            else
                MessageBox.Show("Invalid Username or Password");

            if (loggingIn)
            {
                loginMatch = dataHandler.checkUser(currentUser);
                userID = int.Parse(dataHandler.CheckUsr[0].UserID);
                if (loginMatch)
                {
                    switch (userID)
                    {
                        case -1:
                            MessageBox.Show("Invalid Username or Password");
                            break;

                        case 1:
                            MessageBox.Show("Login successful as admin");
                            DataForm adminForm = new DataForm(1);
                            adminForm.Show();
                            break;

                        default:
                            MessageBox.Show("Login successful as " + currentUser.UserName);
                            DataForm userform = new DataForm(userID);
                            userform.Show();
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("Invalid User or Password");
                } // end if(login)
            } // end if(loggingIn)
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            if (!addingNew)
            {
                tbUsername.Text = "";
                tbPassword.Text = "";
                tbPassword.UseSystemPasswordChar = false;

                MessageBox.Show("Please enter a username and a pasword, then click the New User button again. " +
                    "If you wish to cancel leave both boxes blank and click th New User button again");

                addingNew = true;

            }else if (addingNew)
            {
                currentUser.UserName = tbUsername.Text;
                currentUser.PassWord = tbPassword.Text;

                dataHandler.addNewUser(currentUser);
                addingNew = false;
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCheatLogin_Click(object sender, EventArgs e)
        {
            List<User> presetUsersID = new List<User>();
            presetUsersID.Add(new User("admin", "adminPass", "0"));
            presetUsersID.Add(new User("Sam", "samPass", "1"));
            presetUsersID.Add(new User("Brandon", "branPass", "3"));
            presetUsersID.Add(new User("Peter", "petrPass", "4"));
            presetUsersID.Add(new User("Alex", "alePass", "5"));

            foreach (User u in presetUsersID)
            {
                string userName = u.UserName;
                string passWord = u.PassWord;
                MessageBox.Show("Username: " + userName + " Password: " + passWord);
            }
        }
    }
}
