﻿namespace LoginV2
{
    partial class DataForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label fNameLabel;
            System.Windows.Forms.Label lNameLabel;
            System.Windows.Forms.Label charClass1Label;
            System.Windows.Forms.Label charClass2Label;
            System.Windows.Forms.Label charLevelLabel;
            System.Windows.Forms.Label charGoldLabel;
            this.fNameTextBox = new System.Windows.Forms.TextBox();
            this.cHARACTERSINDNDBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database3DataSet1 = new LoginV2.Database3DataSet1();
            this.lNameTextBox = new System.Windows.Forms.TextBox();
            this.charClass1TextBox = new System.Windows.Forms.TextBox();
            this.charClass2TextBox = new System.Windows.Forms.TextBox();
            this.charLevelTextBox = new System.Windows.Forms.TextBox();
            this.charGoldTextBox = new System.Windows.Forms.TextBox();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNewChar = new System.Windows.Forms.Button();
            this.btnEditChar = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.cHARACTERSINDNDTableAdapter = new LoginV2.Database3DataSet1TableAdapters.CHARACTERSINDNDTableAdapter();
            this.tableAdapterManager = new LoginV2.Database3DataSet1TableAdapters.TableAdapterManager();
            this.lblYouHave = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            fNameLabel = new System.Windows.Forms.Label();
            lNameLabel = new System.Windows.Forms.Label();
            charClass1Label = new System.Windows.Forms.Label();
            charClass2Label = new System.Windows.Forms.Label();
            charLevelLabel = new System.Windows.Forms.Label();
            charGoldLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.cHARACTERSINDNDBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database3DataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // fNameLabel
            // 
            fNameLabel.AutoSize = true;
            fNameLabel.Location = new System.Drawing.Point(30, 80);
            fNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            fNameLabel.Name = "fNameLabel";
            fNameLabel.Size = new System.Drawing.Size(80, 17);
            fNameLabel.TabIndex = 3;
            fNameLabel.Text = "First Name:";
            // 
            // lNameLabel
            // 
            lNameLabel.AutoSize = true;
            lNameLabel.Location = new System.Drawing.Point(30, 112);
            lNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lNameLabel.Name = "lNameLabel";
            lNameLabel.Size = new System.Drawing.Size(80, 17);
            lNameLabel.TabIndex = 5;
            lNameLabel.Text = "Last Name:";
            // 
            // charClass1Label
            // 
            charClass1Label.AutoSize = true;
            charClass1Label.Location = new System.Drawing.Point(30, 144);
            charClass1Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            charClass1Label.Name = "charClass1Label";
            charClass1Label.Size = new System.Drawing.Size(58, 17);
            charClass1Label.TabIndex = 7;
            charClass1Label.Text = "Class 1:";
            // 
            // charClass2Label
            // 
            charClass2Label.AutoSize = true;
            charClass2Label.Location = new System.Drawing.Point(30, 176);
            charClass2Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            charClass2Label.Name = "charClass2Label";
            charClass2Label.Size = new System.Drawing.Size(58, 17);
            charClass2Label.TabIndex = 9;
            charClass2Label.Text = "Class2 :";
            // 
            // charLevelLabel
            // 
            charLevelLabel.AutoSize = true;
            charLevelLabel.Location = new System.Drawing.Point(30, 208);
            charLevelLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            charLevelLabel.Name = "charLevelLabel";
            charLevelLabel.Size = new System.Drawing.Size(46, 17);
            charLevelLabel.TabIndex = 11;
            charLevelLabel.Text = "Level:";
            // 
            // charGoldLabel
            // 
            charGoldLabel.AutoSize = true;
            charGoldLabel.Location = new System.Drawing.Point(30, 240);
            charGoldLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            charGoldLabel.Name = "charGoldLabel";
            charGoldLabel.Size = new System.Drawing.Size(42, 17);
            charGoldLabel.TabIndex = 13;
            charGoldLabel.Text = "Gold:";
            // 
            // fNameTextBox
            // 
            this.fNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cHARACTERSINDNDBindingSource, "fName", true));
            this.fNameTextBox.Location = new System.Drawing.Point(126, 76);
            this.fNameTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fNameTextBox.Name = "fNameTextBox";
            this.fNameTextBox.Size = new System.Drawing.Size(187, 22);
            this.fNameTextBox.TabIndex = 4;
            // 
            // cHARACTERSINDNDBindingSource
            // 
            this.cHARACTERSINDNDBindingSource.DataMember = "CHARACTERSINDND";
            this.cHARACTERSINDNDBindingSource.DataSource = this.database3DataSet1;
            this.cHARACTERSINDNDBindingSource.CurrentChanged += new System.EventHandler(this.cHARACTERSINDNDBindingSource_CurrentChanged);
            // 
            // database3DataSet1
            // 
            this.database3DataSet1.DataSetName = "Database3DataSet1";
            this.database3DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lNameTextBox
            // 
            this.lNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cHARACTERSINDNDBindingSource, "LName", true));
            this.lNameTextBox.Location = new System.Drawing.Point(126, 108);
            this.lNameTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lNameTextBox.Name = "lNameTextBox";
            this.lNameTextBox.Size = new System.Drawing.Size(187, 22);
            this.lNameTextBox.TabIndex = 6;
            // 
            // charClass1TextBox
            // 
            this.charClass1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cHARACTERSINDNDBindingSource, "CharClass1", true));
            this.charClass1TextBox.Location = new System.Drawing.Point(126, 140);
            this.charClass1TextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.charClass1TextBox.Name = "charClass1TextBox";
            this.charClass1TextBox.Size = new System.Drawing.Size(187, 22);
            this.charClass1TextBox.TabIndex = 8;
            // 
            // charClass2TextBox
            // 
            this.charClass2TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cHARACTERSINDNDBindingSource, "CharClass2", true));
            this.charClass2TextBox.Location = new System.Drawing.Point(126, 172);
            this.charClass2TextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.charClass2TextBox.Name = "charClass2TextBox";
            this.charClass2TextBox.Size = new System.Drawing.Size(187, 22);
            this.charClass2TextBox.TabIndex = 10;
            // 
            // charLevelTextBox
            // 
            this.charLevelTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cHARACTERSINDNDBindingSource, "CharLevel", true));
            this.charLevelTextBox.Location = new System.Drawing.Point(126, 204);
            this.charLevelTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.charLevelTextBox.Name = "charLevelTextBox";
            this.charLevelTextBox.Size = new System.Drawing.Size(187, 22);
            this.charLevelTextBox.TabIndex = 12;
            // 
            // charGoldTextBox
            // 
            this.charGoldTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cHARACTERSINDNDBindingSource, "CharGold", true));
            this.charGoldTextBox.Location = new System.Drawing.Point(126, 236);
            this.charGoldTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.charGoldTextBox.Name = "charGoldTextBox";
            this.charGoldTextBox.Size = new System.Drawing.Size(187, 22);
            this.charGoldTextBox.TabIndex = 14;
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(34, 289);
            this.btnFirst.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(64, 28);
            this.btnFirst.TabIndex = 15;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click_1);
            // 
            // btnPrev
            // 
            this.btnPrev.Location = new System.Drawing.Point(106, 289);
            this.btnPrev.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(64, 28);
            this.btnPrev.TabIndex = 16;
            this.btnPrev.Text = "<<";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click_1);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(178, 289);
            this.btnNext.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(64, 28);
            this.btnNext.TabIndex = 17;
            this.btnNext.Text = ">>";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(250, 289);
            this.btnLast.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(64, 28);
            this.btnLast.TabIndex = 18;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click_1);
            // 
            // btnNewChar
            // 
            this.btnNewChar.Location = new System.Drawing.Point(377, 107);
            this.btnNewChar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNewChar.Name = "btnNewChar";
            this.btnNewChar.Size = new System.Drawing.Size(100, 28);
            this.btnNewChar.TabIndex = 19;
            this.btnNewChar.Text = "Create";
            this.btnNewChar.UseVisualStyleBackColor = true;
            this.btnNewChar.Click += new System.EventHandler(this.btnNewChar_Click);
            // 
            // btnEditChar
            // 
            this.btnEditChar.Location = new System.Drawing.Point(377, 140);
            this.btnEditChar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEditChar.Name = "btnEditChar";
            this.btnEditChar.Size = new System.Drawing.Size(100, 28);
            this.btnEditChar.TabIndex = 20;
            this.btnEditChar.Text = "Edit";
            this.btnEditChar.UseVisualStyleBackColor = true;
            this.btnEditChar.Click += new System.EventHandler(this.btnEditChar_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(377, 176);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 28);
            this.btnSave.TabIndex = 21;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cHARACTERSINDNDTableAdapter
            // 
            this.cHARACTERSINDNDTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CHARACTERSINDNDTableAdapter = this.cHARACTERSINDNDTableAdapter;
            this.tableAdapterManager.LogInTableTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = LoginV2.Database3DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // lblYouHave
            // 
            this.lblYouHave.AutoSize = true;
            this.lblYouHave.Location = new System.Drawing.Point(69, 22);
            this.lblYouHave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYouHave.Name = "lblYouHave";
            this.lblYouHave.Size = new System.Drawing.Size(0, 17);
            this.lblYouHave.TabIndex = 22;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(377, 212);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 28);
            this.btnCancel.TabIndex = 23;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // DataForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 409);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblYouHave);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEditChar);
            this.Controls.Add(this.btnNewChar);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrev);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(fNameLabel);
            this.Controls.Add(this.fNameTextBox);
            this.Controls.Add(lNameLabel);
            this.Controls.Add(this.lNameTextBox);
            this.Controls.Add(charClass1Label);
            this.Controls.Add(this.charClass1TextBox);
            this.Controls.Add(charClass2Label);
            this.Controls.Add(this.charClass2TextBox);
            this.Controls.Add(charLevelLabel);
            this.Controls.Add(this.charLevelTextBox);
            this.Controls.Add(charGoldLabel);
            this.Controls.Add(this.charGoldTextBox);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "DataForm";
            this.Text = "Guildhall";
            this.Load += new System.EventHandler(this.DataForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cHARACTERSINDNDBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database3DataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Database3DataSet1 database3DataSet1;
        private System.Windows.Forms.BindingSource cHARACTERSINDNDBindingSource;
        private Database3DataSet1TableAdapters.CHARACTERSINDNDTableAdapter cHARACTERSINDNDTableAdapter;
        private Database3DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox fNameTextBox;
        private System.Windows.Forms.TextBox lNameTextBox;
        private System.Windows.Forms.TextBox charClass1TextBox;
        private System.Windows.Forms.TextBox charClass2TextBox;
        private System.Windows.Forms.TextBox charLevelTextBox;
        private System.Windows.Forms.TextBox charGoldTextBox;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNewChar;
        private System.Windows.Forms.Button btnEditChar;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblYouHave;
        private System.Windows.Forms.Button btnCancel;
    }
}