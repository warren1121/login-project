﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginV2
{
    public partial class DataForm : Form
    {
        DataLayer dataHandler = new DataLayer();
        DataRowView currentRow;
        PlayerChar currChar = new PlayerChar("","","","",0,0,0);
        int currUserID = -1;
        bool editing = false;
        bool creatingNew = false;

        public DataForm()
        {
            InitializeComponent();
        }
        public DataForm(int userID)
        {
            currUserID = userID;
            InitializeComponent();
        }

        private void DataForm_Load(object sender, EventArgs e)
        {
            List<string> establishedList = dataHandler.EstablishList();
            
            List<PlayerChar> playerChars = dataHandler.getCharsFromDBA(currUserID);
            lblYouHave.Text = "You have " + playerChars.Count + " characters";
            bool established = false;

            foreach (string s in establishedList)
            {
                if(s.Equals(currUserID.ToString()))
                {
                    this.cHARACTERSINDNDTableAdapter.Fill(this.database3DataSet1.CHARACTERSINDND);
                    established = true;
                }
            }
            if(established == false)
            {
                MessageBox.Show("You do not have any characters, please create some!");
                fNameTextBox.Text = "";
                lNameTextBox.Text = "";
                charClass1TextBox.Text = "";
                charClass2TextBox.Text = "";
                charLevelTextBox.Text = "";
                charGoldTextBox.Text = "";
            }
        }

        private void cHARACTERSINDNDBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cHARACTERSINDNDBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.database3DataSet1);
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            cHARACTERSINDNDBindingSource.MoveFirst();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            cHARACTERSINDNDBindingSource.MovePrevious();
        }

        private void btnNxt_Click(object sender, EventArgs e)
        {
            cHARACTERSINDNDBindingSource.MoveNext();
            if(currChar.CreatorID != currUserID)
            {
                cHARACTERSINDNDBindingSource.MoveNext();
            }
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            cHARACTERSINDNDBindingSource.MoveLast();
        }

        private void cHARACTERSINDNDBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            currentRow = (DataRowView)cHARACTERSINDNDBindingSource.Current;
            currChar.CreatorID = Convert.ToInt32(currentRow["CreatorID"]);
        }

        private void btnNewChar_Click(object sender, EventArgs e)
        {
            fNameTextBox.Text = "";
            lNameTextBox.Text = "";
            charClass1TextBox.Text = "";
            charClass2TextBox.Text = "";
            charLevelTextBox.Text = "";
            charGoldTextBox.Text = "";

            MessageBox.Show("Fill out the boxes and hit save to create your character." +
                "Information on character creation can be found in the Players Handbook or online at http://company.wizards.com/");
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            cHARACTERSINDNDBindingSource.MoveNext();
        }

        private void btnPrev_Click_1(object sender, EventArgs e)
        {
            cHARACTERSINDNDBindingSource.MovePrevious();
        }

        private void btnFirst_Click_1(object sender, EventArgs e)
        {
            cHARACTERSINDNDBindingSource.MoveFirst();
        }

        private void btnLast_Click_1(object sender, EventArgs e)
        {
            cHARACTERSINDNDBindingSource.MoveLast();
        }

        private void btnEditChar_Click(object sender, EventArgs e)
        {
            currChar.FName = fNameTextBox.Text;
            currChar.LName = lNameTextBox.Text;
            currChar.CharClass1 = charClass1TextBox.Text;
            currChar.CharClass2 = charClass2TextBox.Text;
            currChar.CharLevel = int.Parse(charLevelTextBox.Text);
            currChar.CharGold = int.Parse(charGoldTextBox.Text);

            editing = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (editing)
            {
                currChar.FName = fNameTextBox.Text;
                currChar.LName = lNameTextBox.Text;
                currChar.CharClass1 = charClass1TextBox.Text;
                currChar.CharClass2 = charClass2TextBox.Text;
                currChar.CharLevel = int.Parse(charLevelTextBox.Text);
                currChar.CharGold = int.Parse(charGoldTextBox.Text);

                dataHandler.editChar(currChar);
            }

            if (creatingNew)
            {
                currChar.FName = fNameTextBox.Text;
                currChar.LName = lNameTextBox.Text;
                currChar.CharClass1 = charClass1TextBox.Text;
                currChar.CharClass2 = charClass2TextBox.Text;
                currChar.CharLevel = int.Parse(charLevelTextBox.Text);
                currChar.CharGold = int.Parse(charGoldTextBox.Text);

                dataHandler.addNewChar(currChar);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (editing)
            {
                fNameTextBox.Text = currChar.FName;
                lNameTextBox.Text = currChar.LName;
                charClass1TextBox.Text = currChar.CharClass1;
                charClass2TextBox.Text = currChar.CharClass2;
                charLevelTextBox.Text = currChar.CharLevel.ToString();
                charGoldTextBox.Text = currChar.CharGold.ToString();
            }

            if (creatingNew)
            {
                fNameTextBox.Text = currChar.FName;
                lNameTextBox.Text = currChar.LName;
                charClass1TextBox.Text = currChar.CharClass1;
                charClass2TextBox.Text = currChar.CharClass2;
                charLevelTextBox.Text = currChar.CharLevel.ToString();
                charGoldTextBox.Text = currChar.CharGold.ToString();
            }
        }
    }
}
