﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;

namespace LoginV2
{
    class DataLayer
    {
        private OleDbConnection conn;
        private OleDbCommand comm;
        private OleDbDataReader UserReader;
        private OleDbDataReader CharReader;
        private bool loginMatch = false;
        private List<User> checkUsr;
        private List<string> establishedAccounts = new List<string>();

        internal List<User> CheckUsr { get => checkUsr; set => checkUsr = value; }

        public DataLayer()
        {
            string connString = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=Database3.mdb";
            conn = new OleDbConnection(connString);
        }// end opening connection

        public List<string> EstablishList()
        {
            conn.Open();
            string GetIDs = "SELECT UserID FROM LoginTable";
            comm = new OleDbCommand(GetIDs, conn);

            UserReader = comm.ExecuteReader(CommandBehavior.CloseConnection);
            while (UserReader.Read())
            {
                string usrID = UserReader["UserID"].ToString();

                establishedAccounts.Add(usrID);
            }
            conn.Close();
            return establishedAccounts;
            
        }

        public bool checkUser(User u)
        {
           conn.Open();
           CheckUsr = new List<User>();
           string checkInfo = "SELECT * FROM LoginTable WHERE Username = '" + u.UserName + "'";

           comm = new OleDbCommand(checkInfo, conn);

           UserReader = comm.ExecuteReader(CommandBehavior.CloseConnection);
           while (UserReader.Read())
           {
               string usrID = UserReader["UserID"].ToString();
               string usrNme = UserReader["UserName"].ToString();
               string psWrd = UserReader["UserPass"].ToString();

               CheckUsr.Add(new User(usrNme, psWrd, usrID));
           }
            if (CheckUsr[0].PassWord == u.PassWord)
            {
                loginMatch = true;
            }
            else
            {
                loginMatch = false;
            }
            conn.Close();
            return loginMatch;
        }

        public void addNewUser(User u)
        {
            conn.Open();
            string insertUser = "INSERT INTO LoginTable (UserName,UserPass) VALUES (?,?)";
            comm = new OleDbCommand(insertUser, conn);

            OleDbParameter paramuser = new OleDbParameter("UserName", u.UserName);
            OleDbParameter parampass = new OleDbParameter("UserPass", u.PassWord);

            comm.Parameters.Add(paramuser);
            comm.Parameters.Add(parampass);

            comm.ExecuteNonQuery();
            conn.Close();
        }// end addUser

        public List<PlayerChar> getCharsFromDBA(int i)
        {
            List<PlayerChar> usersChars = new List<PlayerChar>();

            string selectChars = "SELECT * FROM CHARACTERSINDND WHERE CreatorID = @CreatorID;";

            {
                using (OleDbCommand comm = new OleDbCommand(selectChars, conn))
                {
                    int usrID = i;
                    OleDbParameter createID = new OleDbParameter("@CreatorID", usrID);
                    comm.Parameters.Add(createID);
                    
                    conn.Open();

                    CharReader = comm.ExecuteReader();
                    {
                        while (CharReader.Read())
                        {
                            string fName = CharReader["fName"].ToString();
                            string lName = CharReader["LName"].ToString();
                            string ChrCls1 = CharReader["CharClass1"].ToString();
                            string ChrCls2 = CharReader["CharClass2"].ToString();
                            int level = int.Parse(CharReader["CharLevel"].ToString());
                            int gld = int.Parse(CharReader["CharGold"].ToString());
                            int cre = int.Parse(CharReader["CreatorID"].ToString());

                            usersChars.Add(new PlayerChar(fName, lName, ChrCls1, ChrCls2, level, gld, cre));
                        }//end While
                    }
                }
            }
            CharReader.Close();
            conn.Close();
            return usersChars;
        }


        public void editChar(PlayerChar pc)
        {
            conn.Open();

            string updateChar = "UPDATE CHARACTERSINDND SET fName =?, LName =?, CharClass1 =?, CharClass2=?, CharLevel =?, CharGold =?";
            comm = new OleDbCommand(updateChar, conn);

            OleDbParameter paramFirst = new OleDbParameter("fName", pc.FName);
            OleDbParameter paramLast = new OleDbParameter("LName", pc.LName);
            OleDbParameter paramClass1 = new OleDbParameter("CharClass1", pc.CharClass1);
            OleDbParameter paramClass2 = new OleDbParameter("CharClass2", pc.CharClass2);
            OleDbParameter paramLevel = new OleDbParameter("CharLevel", pc.CharLevel);
            OleDbParameter paramGold = new OleDbParameter("CharGold", pc.CharGold);

            comm.Parameters.Add(paramFirst);
            comm.Parameters.Add(paramLast);
            comm.Parameters.Add(paramClass1);
            comm.Parameters.Add(paramClass2);
            comm.Parameters.Add(paramLevel);
            comm.Parameters.Add(paramGold);

            comm.ExecuteNonQuery();
            conn.Close();
        }

        public void addNewChar(PlayerChar pc) 
        {
            conn.Open();

            string addChar = "INSERT INTO CHARACTERSINDND (fName, LName, CharClass1, CharClass, CharLevel, CharGold) VALUES (?,?,?,?,?,?)";
            comm = new OleDbCommand(addChar, conn);

            OleDbParameter paramFirst = new OleDbParameter("fName", pc.FName);
            OleDbParameter paramLast = new OleDbParameter("LName", pc.LName);
            OleDbParameter paramClass1 = new OleDbParameter("CharClass1", pc.CharClass1);
            OleDbParameter paramClass2 = new OleDbParameter("CharClass2", pc.CharClass2);
            OleDbParameter paramLevel = new OleDbParameter("CharLevel", pc.CharLevel);
            OleDbParameter paramGold = new OleDbParameter("CharGold", pc.CharGold);

            comm.Parameters.Add(paramFirst);
            comm.Parameters.Add(paramLast);
            comm.Parameters.Add(paramClass1);
            comm.Parameters.Add(paramClass2);
            comm.Parameters.Add(paramLevel);
            comm.Parameters.Add(paramGold);

            comm.ExecuteNonQuery();
            conn.Close();
        }

    }
}
