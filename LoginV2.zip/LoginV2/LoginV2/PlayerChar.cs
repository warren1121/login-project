﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginV2
{
    class PlayerChar
    {
        private string fName, lName, charClass1, charClass2;
        private int charLevel, charGold, creatorID;

        public PlayerChar()
        {

        }// default constructor

        public PlayerChar(string f, string l, string cl1, string cl2, int lv, int g, int cr)
        {
            FName = f;
            LName = l;
            CharClass1 = cl1;
            CharClass2 = cl2;
            CharLevel = lv;
            CharGold = g;
            CreatorID = cr;
        }

        public string FName { get => fName; set => fName = value; }
        public string LName { get => lName; set => lName = value; }
        public string CharClass1 { get => charClass1; set => charClass1 = value; }
        public string CharClass2 { get => charClass2; set => charClass2 = value; }
        public int CharLevel { get => charLevel; set => charLevel = value; }
        public int CharGold { get => charGold; set => charGold = value; }
        public int CreatorID { get => creatorID; set => creatorID = value; }
    }
}
